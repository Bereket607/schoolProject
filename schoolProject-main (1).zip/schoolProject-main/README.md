# Image Editor

## Description
This app allows the user to:
- Trim the borders of the image
- Show negative color of Image
- Stretch the image horizontally
- Shrink the image vertically
- Invert the image

## Technologies
This app is built using Java.
